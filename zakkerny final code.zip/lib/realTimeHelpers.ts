import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  limit,
  updateDoc,
  doc
} from 'firebase/firestore';
import { db } from './firebase';
import { NotificationData, UserData, MedicationData } from './firebaseHelpers';

// Real-time notifications for caregivers
export const subscribeToCaregiverNotifications = (
  caregiverId: string, 
  callback: (notifications: NotificationData[]) => void
) => {
  const notificationsRef = collection(db, 'notifications');
  const q = query(
    notificationsRef,
    where('caregiverId', '==', caregiverId),
    where('isRead', '==', false),
    orderBy('createdAt', 'desc'),
    limit(20)
  );

  return onSnapshot(q, (snapshot) => {
    const notifications = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as NotificationData));
    
    callback(notifications);
  });
};

// Real-time linked users for caregivers
export const subscribeToLinkedUsers = (
  caregiverId: string,
  callback: (users: UserData[]) => void
) => {
  const usersRef = collection(db, 'users');
  const q = query(
    usersRef,
    where('linkedCaregiver', '==', caregiverId)
  );

  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as UserData));
    
    callback(users);
  });
};

// Real-time medications for users
export const subscribeToUserMedications = (
  userId: string,
  callback: (medications: MedicationData[]) => void
) => {
  const medicationsRef = collection(db, 'medications');
  const q = query(
    medicationsRef,
    where('userId', '==', userId),
    where('isActive', '==', true),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const medications = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as MedicationData));
    
    callback(medications);
  });
};

// Mark notification as read
export const markNotificationAsRead = async (notificationId: string) => {
  try {
    await updateDoc(doc(db, 'notifications', notificationId), {
      isRead: true
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
  }
};

// Real-time user notifications
export const subscribeToUserNotifications = (
  userId: string,
  callback: (notifications: NotificationData[]) => void
) => {
  const notificationsRef = collection(db, 'notifications');
  const q = query(
    notificationsRef,
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(10)
  );

  return onSnapshot(q, (snapshot) => {
    const notifications = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as NotificationData));
    
    callback(notifications);
  });
};