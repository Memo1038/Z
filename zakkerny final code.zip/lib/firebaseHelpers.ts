
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  query, 
  where,
  serverTimestamp,
  Timestamp 
} from 'firebase/firestore';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from './firebase';

export interface UserData {
  id: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  accountType: 'user' | 'caregiver';
  caregiverCode?: string;
  linkedUsers?: string[];
  linkedCaregiver?: string;
  createdAt: Timestamp;
  fcmToken?: string;
}

export interface MedicationData {
  id: string;
  userId: string;
  name: string;
  dosage: string;
  frequency: number;
  times: string[];
  startDate: string;
  endDate?: string;
  instructions?: string;
  isActive: boolean;
  createdAt: Timestamp;
}

export interface NotificationData {
  id: string;
  userId: string;
  caregiverId?: string;
  type: 'medication_reminder' | 'missed_dose' | 'snoozed_3_times';
  title: string;
  message: string;
  medicationId?: string;
  isRead: boolean;
  createdAt: Timestamp;
}

// User Functions
export const createUser = async (userData: Omit<UserData, 'id' | 'createdAt'> & { password: string }) => {
  try {
    // إنشاء المستخدم في Firebase Auth
    const userCredential = await createUserWithEmailAndPassword(auth, userData.email, userData.password);
    const userId = userCredential.user.uid;

    // إعداد بيانات المستخدم للحفظ في Firestore
    const userDataForFirestore: UserData = {
      id: userId,
      name: userData.name,
      email: userData.email,
      phone: userData.phone,
      country: userData.country,
      accountType: userData.accountType,
      caregiverCode: userData.caregiverCode,
      createdAt: serverTimestamp() as Timestamp
    };

    // حفظ بيانات المستخدم في Firestore
    await setDoc(doc(db, 'users', userId), userDataForFirestore);

    console.log('تم إنشاء المستخدم بنجاح في Firebase:', {
      id: userId,
      name: userData.name,
      email: userData.email,
      phone: userData.phone,
      country: userData.country,
      accountType: userData.accountType
    });

    return userDataForFirestore;
  } catch (error) {
    console.error('خطأ في إنشاء المستخدم:', error);
    throw error;
  }
};

export const getUserById = async (userId: string): Promise<UserData | null> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    return userDoc.exists() ? userDoc.data() as UserData : null;
  } catch (error) {
    console.error('Error getting user:', error);
    return null;
  }
};

export const linkUserToCaregiver = async (userCode: string, caregiverId: string) => {
  try {
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('caregiverCode', '==', userCode));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      throw new Error('Invalid user code');
    }

    const userDoc = querySnapshot.docs[0];
    const userId = userDoc.id;

    // Update user with caregiver link
    await updateDoc(doc(db, 'users', userId), {
      linkedCaregiver: caregiverId
    });

    // Update caregiver with user link
    const caregiverDoc = await getDoc(doc(db, 'users', caregiverId));
    if (caregiverDoc.exists()) {
      const caregiverData = caregiverDoc.data() as UserData;
      const linkedUsers = caregiverData.linkedUsers || [];
      if (!linkedUsers.includes(userId)) {
        linkedUsers.push(userId);
        await updateDoc(doc(db, 'users', caregiverId), {
          linkedUsers
        });
      }
    }

    return userId;
  } catch (error) {
    console.error('Error linking user to caregiver:', error);
    throw error;
  }
};

// Medication Functions
export const addMedication = async (medicationData: Omit<MedicationData, 'id' | 'createdAt'>) => {
  try {
    const medRef = doc(collection(db, 'medications'));
    const newMedication: MedicationData = {
      ...medicationData,
      id: medRef.id,
      createdAt: serverTimestamp() as Timestamp
    };

    await setDoc(medRef, newMedication);
    return newMedication;
  } catch (error) {
    console.error('Error adding medication:', error);
    throw error;
  }
};

export const getUserMedications = async (userId: string): Promise<MedicationData[]> => {
  try {
    const medsRef = collection(db, 'medications');
    const q = query(medsRef, where('userId', '==', userId), where('isActive', '==', true));
    const querySnapshot = await getDocs(q);

    return querySnapshot.docs.map(doc => doc.data() as MedicationData);
  } catch (error) {
    console.error('Error getting medications:', error);
    return [];
  }
};

// Notification Functions
export const createNotification = async (notificationData: Omit<NotificationData, 'id' | 'createdAt'>) => {
  try {
    const notifRef = doc(collection(db, 'notifications'));
    const newNotification: NotificationData = {
      ...notificationData,
      id: notifRef.id,
      createdAt: serverTimestamp() as Timestamp
    };

    await setDoc(notifRef, newNotification);
    return newNotification;
  } catch (error) {
    console.error('Error creating notification:', error);
    throw error;
  }
};

export const getUserNotifications = async (userId: string): Promise<NotificationData[]> => {
  try {
    const notifsRef = collection(db, 'notifications');
    const q = query(notifsRef, where('userId', '==', userId));
    const querySnapshot = await getDocs(q);

    return querySnapshot.docs.map(doc => doc.data() as NotificationData);
  } catch (error) {
    console.error('Error getting notifications:', error);
    return [];
  }
};

export const getCaregiverNotifications = async (caregiverId: string): Promise<NotificationData[]> => {
  try {
    const notifsRef = collection(db, 'notifications');
    const q = query(notifsRef, where('caregiverId', '==', caregiverId));
    const querySnapshot = await getDocs(q);

    return querySnapshot.docs.map(doc => doc.data() as NotificationData);
  } catch (error) {
    console.error('Error getting caregiver notifications:', error);
    return [];
  }
};

// Generate unique caregiver code for users
export const generateCaregiverCode = (): string => {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
};
