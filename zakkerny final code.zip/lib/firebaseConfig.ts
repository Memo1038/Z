
export const FIREBASE_CONFIG_GUIDE = {
  steps: [
    "1. اذهب إلى https://console.firebase.google.com",
    "2. أنشئ مشروع جديد أو استخدم مشروع موجود",
    "3. في إعدادات المشروع، انسخ معلومات التكوين",
    "4. استبدل القيم في lib/firebase.ts",
    "5. فعّل Authentication و Firestore Database",
    "6. أضف VAPID key للإشعارات"
  ],
  requiredServices: [
    "Authentication (Email/Password)",
    "Firestore Database", 
    "Cloud Messaging",
    "Hosting (اختياري)"
  ]
};

// استبدل هذه القيم بقيم مشروعك الحقيقي من Firebase Console
export const FIREBASE_CONFIG_TEMPLATE = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "medication-reminder-xxxxx.firebaseapp.com",
  projectId: "medication-reminder-xxxxx",
  storageBucket: "medication-reminder-xxxxx.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456789012345",
  measurementId: "G-XXXXXXXXXX"
};

export const VAPID_KEY_TEMPLATE = "BHXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxX";
