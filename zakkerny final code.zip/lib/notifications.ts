
import { messaging } from './firebase';
import { createNotification } from './firebaseHelpers';

// ⚠️ Replace with your actual VAPID key from Firebase Console
const VAPID_KEY = 'BHXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxXxX';

// Request notification permission
export const requestNotificationPermission = async () => {
  try {
    // Guard against environments where Notification API is not available
    if (!('Notification' in window)) {
      console.warn('Notification API not supported in this browser.');
      return 'denied' as NotificationPermission;
    }

    const permission = await Notification.requestPermission();

    if (permission === 'granted') {
      console.log('Notification permission granted');

      const messagingInstance = await messaging();
      if (messagingInstance) {
        // You can get FCM token here if needed
        console.log('FCM messaging ready');
      }
    } else {
      console.log('Notification permission denied');
    }

    return permission;
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return 'denied' as NotificationPermission;
  }
};

// Schedule medication reminder
export const scheduleMedicationReminder = async (
  medicationName: string,
  time: string,
  userId: string,
  medicationId: string
) => {
  try {
    // Calculate notification time
    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const reminderTime = new Date();

    reminderTime.setHours(hours, minutes, 0, 0);

    // If time has passed today, schedule for tomorrow
    if (reminderTime <= now) {
      reminderTime.setDate(reminderTime.getDate() + 1);
    }

    const timeUntilReminder = reminderTime.getTime() - now.getTime();

    // Defensive: ensure we never pass a negative timeout to setTimeout
    const safeDelay = Math.max(timeUntilReminder, 0);

    // Schedule browser notification
    setTimeout(() => {
      showMedicationNotification(medicationName, time, userId, medicationId);
    }, safeDelay);

    console.log(
      `Medication reminder scheduled for ${medicationName} at ${time}`
    );
  } catch (error) {
    console.error('Error scheduling medication reminder:', error);
  }
};

// Show medication notification
export const showMedicationNotification = async (
  medicationName: string,
  time: string,
  userId: string,
  medicationId: string
) => {
  try {
    // Guard against missing Notification API
    if (!('Notification' in window)) {
      console.warn('Notification API not supported in this browser.');
      return;
    }

    if (Notification.permission === 'granted') {
      const notification = new Notification('وقت تناول الدواء', {
        body: `حان وقت تناول ${medicationName}`,
        icon:
          'https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png',
        badge:
          'https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png',
        actions: [
          { action: 'taken', title: 'تم التناول' },
          { action: 'snooze', title: 'تأجيل 10 دقائق' },
        ],
        requireInteraction: true,
        timestamp: Date.now(),
      });

      // Handle notification click
      notification.onclick = () => {
        window.focus();
        notification.close();
      };
    }

    // Store notification in database
    await createNotification({
      userId,
      type: 'medication_reminder',
      title: 'وقت تناول الدواء',
      message: `حان وقت تناول ${medicationName}`,
      medicationId,
      isRead: false,
    });
  } catch (error) {
    console.error('Error showing medication notification:', error);
  }
};

// Handle snooze functionality
export const handleSnooze = async (
  userId: string,
  medicationId: string,
  caregiverId?: string
) => {
  try {
    // Reschedule notification for 10 minutes later
    setTimeout(() => {
      // Note: we fire fire-and-forget; any errors are logged inside showMedicationNotification
      showMedicationNotification('الدواء المؤجل', '10 minutes later', userId, medicationId);
    }, 10 * 60 * 1000); // 10 minutes

    // Track snooze count (simple in‑memory tracker)
    const snoozeCount = getSnoozeCount(medicationId) + 1;
    setSnoozeCount(medicationId, snoozeCount);

    // If snoozed 3 times, notify caregiver
    if (snoozeCount >= 3 && caregiverId) {
      await createNotification({
        userId,
        caregiverId,
        type: 'snoozed_3_times',
        title: 'تحذير: تأجيل متكرر',
        message: 'المريض أجل تناول الدواء 3 مرات متتالية',
        medicationId,
        isRead: false,
      });

      // Show caregiver notification (guarded)
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('تحذير من ذكرني', {
          body: 'المريض أجل تناول الدواء 3 مرات متتالية',
          icon:
            'https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png',
        });
      }
    }
  } catch (error) {
    console.error('Error handling snooze:', error);
  }
};

// Helper functions for snooze tracking
// Initialise the tracker as an empty object to avoid “Unexpected ;” syntax error
let snoozeTracker: Record<string, number> = {};

const getSnoozeCount = (medicationId: string): number => {
  return snoozeTracker[medicationId] ?? 0;
};

const setSnoozeCount = (medicationId: string, count: number) => {
  snoozeTracker[medicationId] = count;
};

// Send missed dose notification to caregiver
export const notifyMissedDose = async (
  userId: string,
  medicationName: string,
  time: string,
  caregiverId: string
) => {
  try {
    await createNotification({
      userId,
      caregiverId,
      type: 'missed_dose',
      title: 'جرعة مفقودة',
      message: `لم يتم تناول ${medicationName} في الوقت المحدد ${time}`,
      isRead: false,
    });

    console.log('Missed dose notification sent to caregiver');
  } catch (error) {
    console.error('Error sending missed dose notification:', error);
  }
};
