'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createUser, linkUserToCaregiver, generateCaregiverCode } from '@/lib/firebaseHelpers';
import { countries } from '@/lib/countries';

export default function Signup() {
  const [language, setLanguage] = useState('ar');
  const [accountType, setAccountType] = useState('user');
  const [selectedCountry, setSelectedCountry] = useState(countries[0]);
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    caregiverCode: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  // Auto-detect user's country with multiple fallback APIs
  useEffect(() => {
    const detectCountry = async () => {
      const detectAPIs = [
        'https://ipapi.co/json/',
        'https://ip-api.com/json/',
        'https://ipinfo.io/json'
      ];

      for (const api of detectAPIs) {
        try {
          const response = await fetch(api);
          if (!response.ok) continue;

          const data = await response.json();
          let countryCode = '';

          // Handle different API response formats
          if (api.includes('ipapi.co')) {
            countryCode = data.country_code;
          } else if (api.includes('ip-api.com')) {
            countryCode = data.countryCode;
          } else if (api.includes('ipinfo.io')) {
            countryCode = data.country;
          }

          if (countryCode) {
            // Find matching country in our list
            const detectedCountry = countries.find(country =>
              country.value === countryCode.toUpperCase()
            );

            if (detectedCountry) {
              setSelectedCountry(detectedCountry);
              console.log('Country detected:', detectedCountry.labelEn);
              return; // Success, exit the loop
            }
          }
        } catch (error) {
          console.log(`Failed to detect country from ${api}:`, error);
        }
      }

      console.log('Could not detect country, using default (Egypt)');
    };

    detectCountry();
  }, []);

  const translations = {
    ar: {
      title: 'إنشاء حساب جديد',
      user: 'مستخدم',
      caregiver: 'مقدم رعاية',
      name: 'الاسم الكامل',
      email: 'البريد الإلكتروني',
      country: 'الدولة',
      phone: 'رقم الهاتف',
      password: 'كلمة المرور',
      confirmPassword: 'تأكيد كلمة المرور',
      caregiverCode: 'رمز ربط المستخدم',
      signup: 'إنشاء حساب',
      haveAccount: 'لديك حساب بالفعل؟',
      login: 'تسجيل الدخول',
      back: 'رجوع',
      caregiverNote: 'أدخل رمز المستخدم للربط معه',
      passwordMismatch: 'كلمات المرور غير متطابقة',
      invalidCode: 'رمز المستخدم غير صحيح',
      accountCreated: 'تم إنشاء الحساب بنجاح'
    },
    en: {
      title: 'Create New Account',
      user: 'User',
      caregiver: 'Caregiver',
      name: 'Full Name',
      email: 'Email',
      country: 'Country',
      phone: 'Phone Number',
      password: 'Password',
      confirmPassword: 'Confirm Password',
      caregiverCode: 'User Link Code',
      signup: 'Sign Up',
      haveAccount: 'Already have an account?',
      login: 'Login',
      back: 'Back',
      caregiverNote: 'Enter user code to link with them',
      passwordMismatch: 'Passwords do not match',
      invalidCode: 'Invalid user code',
      accountCreated: 'Account created successfully'
    }
  };

  const t = translations[language as keyof typeof translations];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError(t.passwordMismatch);
      return;
    }

    setIsLoading(true);

    try {
      // إعداد بيانات المستخدم مع كلمة المرور
      const userData = {
        name: formData.name,
        email: formData.email,
        phone: `${selectedCountry.code}${formData.phone}`,
        country: selectedCountry.value,
        accountType: accountType as 'user' | 'caregiver',
        caregiverCode: accountType === 'user' ? generateCaregiverCode() : undefined,
        password: formData.password
      };

      console.log('إرسال بيانات المستخدم إلى Firebase:', {
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        country: userData.country,
        accountType: userData.accountType
      });

      const newUser = await createUser(userData);

      // إذا كان مقدم رعاية، ربطه بالمستخدم
      if (accountType === 'caregiver' && formData.caregiverCode) {
        try {
          await linkUserToCaregiver(formData.caregiverCode, newUser.id);
        } catch (error) {
          setError(t.invalidCode);
          setIsLoading(false);
          return;
        }
      }

      // حفظ بيانات المستخدم في localStorage للعرض
      localStorage.setItem('currentUser', JSON.stringify(newUser));

      console.log('تم إنشاء الحساب بنجاح وحفظ البيانات في Firebase');

      // التوجه إلى اللوحة المناسبة
      if (accountType === 'user') {
        router.push('/dashboard');
      } else {
        router.push('/caregiver-dashboard');
      }
    } catch (error: any) {
      console.error('خطأ في إنشاء الحساب:', error);
      if (error.code === 'auth/email-already-in-use') {
        setError('البريد الإلكتروني مستخدم بالفعل');
      } else if (error.code === 'auth/weak-password') {
        setError('كلمة المرور ضعيفة، يجب أن تكون 6 أحرف على الأقل');
      } else {
        setError('خطأ في إنشاء الحساب. حاول مرة أخرى.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Handle phone number input - only allow numbers
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow digits and limit length
    const cleanedValue = value.replace(/[^0-9]/g, '').slice(0, 15);
    setFormData({ ...formData, phone: cleanedValue });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#28C6B7]/20 to-[#28C6B7]/40">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <Link href="/">
          <button className="w-10 h-10 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg">
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </button>
        </Link>
        <button
          onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          className="bg-white/80 backdrop-blur-sm px-3 py-2 rounded-full shadow-lg text-sm font-medium text-gray-700"
        >
          {language === 'ar' ? 'EN' : 'العربية'}
        </button>
      </div>

      <div className="px-6 pt-4">
        {/* Logo */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 mx-auto mb-3 rounded-3xl flex items-center justify-center shadow-xl overflow-hidden bg-white">
            <img 
              src="https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png"
              alt="ذكرني"
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-xl font-bold text-gray-800">{t.title}</h1>
        </div>

        {/* Account Type Toggle */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-1 mb-4 shadow-lg">
          <div className="grid grid-cols-2 gap-1">
            <button
              onClick={() => setAccountType('user')}
              className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                accountType === 'user'
                  ? 'bg-[#28C6B7] text-white shadow-lg'
                  : 'text-gray-600 hover:bg-white/50'
              }`}
            >
              {t.user}
            </button>
            <button
              onClick={() => setAccountType('caregiver')}
              className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                accountType === 'caregiver'
                  ? 'bg-[#28C6B7] text-white shadow-lg'
                  : 'text-gray-600 hover:bg-white/50'
              }`}
            >
              {t.caregiver}
            </button>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-2xl mb-4">
            {error}
          </div>
        )}

        {/* Signup Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="text"
            placeholder={t.name}
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none"
            required
          />

          <input
            type="email"
            placeholder={t.email}
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none"
            required
          />

          {/* Country Selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowCountryDropdown(!showCountryDropdown)}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none flex items-center justify-between"
            >
              <span>{language === 'ar' ? selectedCountry.label : selectedCountry.labelEn} ({selectedCountry.code})</span>
              <i className={`ri-arrow-${showCountryDropdown ? 'up' : 'down'}-line`}></i>
            </button>

            {showCountryDropdown && (
              <div className="absolute top-full left-0 right-0 bg-white rounded-2xl shadow-xl z-50 max-h-60 overflow-y-auto mt-1">
                {countries.map((country) => (
                  <button
                    key={country.value}
                    type="button"
                    onClick={() => {
                      setSelectedCountry(country);
                      setShowCountryDropdown(false);
                    }}
                    className="w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center justify-between"
                  >
                    <span>{language === 'ar' ? country.label : country.labelEn}</span>
                    <span className="text-gray-500">{country.code}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Phone Number - Fixed Input */}
          <div className="flex gap-2">
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl px-4 py-4 shadow-lg flex items-center justify-center text-gray-700 font-medium min-w-20">
              {selectedCountry.code}
            </div>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              placeholder={t.phone}
              value={formData.phone}
              onChange={handlePhoneChange}
              className="flex-1 bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none"
              required
              maxLength={15}
            />
          </div>

          <input
            type="password"
            placeholder={t.password}
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none"
            required
          />

          <input
            type="password"
            placeholder={t.confirmPassword}
            value={formData.confirmPassword}
            onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
            className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none"
            required
          />

          {accountType === 'caregiver' && (
            <div>
              <input
                type="text"
                placeholder={t.caregiverCode}
                value={formData.caregiverCode}
                onChange={(e) => setFormData({ ...formData, caregiverCode: e.target.value.toUpperCase() })}
                className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-[#28C6B7] focus:outline-none"
                required
              />
              <p className="text-xs text-gray-600 mt-2 px-2">{t.caregiverNote}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-[#28C6B7] to-[#28C6B7]/80 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl hover:shadow-2xl transition-all disabled:opacity-50 !rounded-button"
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                {t.signup}
              </div>
            ) : (
              t.signup
            )}
          </button>
        </form>

        {/* Footer Links */}
        <div className="text-center mt-4 mb-8">
          <div className="text-gray-600 text-sm">
            {t.haveAccount}{' '}
            <Link href="/login" className="text-[#ff9c2e] font-medium">
              {t.login}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}