
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { handleSnooze, requestNotificationPermission } from '@/lib/notifications';
import { getUserMedications, MedicationData } from '@/lib/firebaseHelpers';

export default function Dashboard() {
  const [language, setLanguage] = useState('ar');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [medications, setMedications] = useState<MedicationData[]>([]);

  const translations = {
    ar: {
      goodMorning: 'صباح الخير',
      goodAfternoon: 'مساء الخير',
      goodEvening: 'تصبح على خير',
      todaysMeds: 'أدوية اليوم',
      nextDose: 'الجرعة التالية',
      taken: 'تم التناول',
      snooze: 'تأجيل',
      skip: 'تخطي',
      addMed: 'إضافة دواء',
      myMeds: 'أدويتي',
      reports: 'التقارير',
      settings: 'الإعدادات',
      profile: 'الملف الشخصي',
      linkCode: 'رمز الربط'
    },
    en: {
      goodMorning: 'Good Morning',
      goodAfternoon: 'Good Afternoon',
      goodEvening: 'Good Evening',
      todaysMeds: "Today's Medications",
      nextDose: 'Next Dose',
      taken: 'Taken',
      snooze: 'Snooze',
      skip: 'Skip',
      addMed: 'Add Medication',
      myMeds: 'My Medications',
      reports: 'Reports',
      settings: 'Settings',
      profile: 'Profile',
      linkCode: 'Link Code'
    }
  };

  const t = translations[language as keyof typeof translations];

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Get current user and medications from localStorage/Firebase
    const user = localStorage.getItem('currentUser');
    if (user) {
      const userData = JSON.parse(user);
      setCurrentUser(userData);

      // Load user medications
      getUserMedications(userData.id).then(setMedications);
    }

    // Request notification permission
    requestNotificationPermission();
  }, []);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return t.goodMorning;
    if (hour < 18) return t.goodAfternoon;
    return t.goodEvening;
  };

  // Mock today's medications with real data
  const todaysMeds = [
    { id: 1, name: 'أسبرين', nameEn: 'Aspirin', time: '08:00', taken: true, dosage: '100mg' },
    { id: 2, name: 'فيتامين د', nameEn: 'Vitamin D', time: '12:00', taken: false, dosage: '1000 IU', isNext: true },
    { id: 3, name: 'أوميجا 3', nameEn: 'Omega 3', time: '18:00', taken: false, dosage: '500mg' },
    { id: 4, name: 'كالسيوم', nameEn: 'Calcium', time: '20:00', taken: false, dosage: '600mg' }
  ];

  const handleMedicationSnooze = async (medicationId: number) => {
    if (currentUser && currentUser.linkedCaregiver) {
      await handleSnooze(currentUser.id, medicationId.toString(), currentUser.linkedCaregiver);
    }

    // Update UI to show snooze
    console.log('Medication snoozed for 10 minutes');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-gray-800">{getGreeting()}</h1>
            <p className="text-sm text-gray-600" suppressHydrationWarning={true}>
              {currentTime.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium"
            >
              {language === 'ar' ? 'EN' : 'ع'}
            </button>
            <Link href="/profile">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                <i className="ri-user-line text-white text-lg"></i>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-24 px-4">
        {/* User Info Card */}
        {currentUser && (
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-semibold text-gray-800">{currentUser.name}</h2>
                <p className="text-sm text-gray-600">{currentUser.phone}</p>
              </div>
              <Link href="/user-code">
                <button className="bg-blue-500 text-white px-3 py-2 rounded-full text-sm !rounded-button">
                  <i className="ri-qr-code-line mr-1"></i>
                  {t.linkCode}
                </button>
              </Link>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-check-line text-green-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">3</p>
            <p className="text-xs text-gray-600">{t.taken}</p>
          </div>
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 bg-blue-100 rounded-full flex items-center justify-center">
              <i className="ri-medicine-bottle-line text-blue-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">{medications.length || 8}</p>
            <p className="text-xs text-gray-600">{t.myMeds}</p>
          </div>
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 bg-orange-100 rounded-full flex items-center justify-center">
              <i className="ri-time-line text-orange-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">12:00</p>
            <p className="text-xs text-gray-600">{t.nextDose}</p>
          </div>
        </div>

        {/* Today's Medications */}
        <div className="mb-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">{t.todaysMeds}</h2>
          <div className="space-y-3">
            {todaysMeds.map((med) => (
              <div
                key={med.id}
                className={`bg-white/70 backdrop-blur-sm rounded-2xl p-4 shadow-lg ${
                  med.isNext ? 'ring-2 ring-blue-500 bg-blue-50/70' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        med.taken
                          ? 'bg-green-100'
                          : med.isNext
                            ? 'bg-blue-100'
                            : 'bg-gray-100'
                      }`}
                    >
                      <i
                        className={`ri-medicine-bottle-line text-xl ${
                          med.taken
                            ? 'text-green-600'
                            : med.isNext
                              ? 'text-blue-600'
                              : 'text-gray-600'
                        }`}
                      ></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800">
                        {language === 'ar' ? med.name : med.nameEn}
                      </h3>
                      <p className="text-sm text-gray-600">{med.dosage} • {med.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {med.taken ? (
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                        <i className="ri-check-line text-white text-sm"></i>
                      </div>
                    ) : med.isNext ? (
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleMedicationSnooze(med.id)}
                          className="px-3 py-1 bg-orange-500 text-white rounded-full text-xs !rounded-button"
                        >
                          {t.snooze}
                        </button>
                        <button className="px-3 py-1 bg-green-500 text-white rounded-full text-xs !rounded-button">
                          {t.taken}
                        </button>
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add Medication Button */}
        <Link href="/add-medication">
          <button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl mb-6 !rounded-button">
            <i className="ri-add-line mr-2"></i>
            {t.addMed}
          </button>
        </Link>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-4 gap-1">
          <Link href="/dashboard" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-home-fill text-blue-600 text-lg"></i>
            </div>
            <span className="text-xs text-blue-600 font-medium">الرئيسية</span>
          </Link>
          <Link href="/medications" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-medicine-bottle-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">{t.myMeds}</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">{t.reports}</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-settings-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">{t.settings}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
