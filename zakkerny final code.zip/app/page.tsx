
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Home() {
  const [language, setLanguage] = useState('ar');
  const [isLoading, setIsLoading] = useState(true);

  const translations = {
    ar: {
      welcome: 'مرحباً بك في ذكرني',
      subtitle: 'تطبيقك الذكي لإدارة الأدوية',
      login: 'تسجيل الدخول',
      signup: 'إنشاء حساب جديد',
      features: {
        reminders: 'تذكيرات الأدوية',
        caregivers: 'ربط مع مقدم الرعاية',
        tracking: 'تتبع الجرعات',
        reports: 'تقارير مفصلة'
      }
    },
    en: {
      welcome: 'Welcome to Dhakerni',
      subtitle: 'Your Smart Medication Management App',
      login: 'Login',
      signup: 'Sign Up',
      features: {
        reminders: 'Medication Reminders',
        caregivers: 'Caregiver Connection',
        tracking: 'Dose Tracking',
        reports: 'Detailed Reports'
      }
    }
  };

  const t = translations[language as keyof typeof translations];

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center overflow-hidden">
            <img 
              src="https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png"
              alt="ذكرني"
              className="w-full h-full object-contain"
            />
          </div>
          <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-500 rounded-full animate-spin mx-auto"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Language Toggle */}
      <div className="fixed top-4 right-4 z-50">
        <button
          onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          className="bg-white/90 backdrop-blur-sm px-3 py-2 rounded-full shadow-lg text-sm font-medium text-gray-700 hover:bg-white transition-all"
        >
          {language === 'ar' ? 'EN' : 'العربية'}
        </button>
      </div>

      {/* Hero Section */}
      <div className="px-6 pt-16 pb-8">
        <div className="text-center mb-8">
          <div className="w-24 h-24 mx-auto mb-6 rounded-3xl flex items-center justify-center shadow-xl overflow-hidden bg-white">
            <img 
              src="https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png"
              alt="ذكرني"
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2 font-['Pacifico']">
            {language === 'ar' ? 'ذكرني' : 'Dhakerni'}
          </h1>
          <p className="text-gray-600 text-lg">{t.subtitle}</p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {Object.entries(t.features).map(([key, value], index) => {
            const icons = ['ri-alarm-line', 'ri-heart-line', 'ri-bar-chart-line', 'ri-file-list-line'];
            return (
              <div key={key} className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
                <div className="w-12 h-12 mx-auto mb-3 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className={`${icons[index]} text-xl text-blue-600`}></i>
                </div>
                <p className="text-sm font-medium text-gray-700">{value}</p>
              </div>
            );
          })}
        </div>

        {/* CTA Buttons */}
        <div className="space-y-4">
          <Link href="/login" className="block">
            <button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl hover:shadow-2xl transition-all !rounded-button">
              {t.login}
            </button>
          </Link>
          <Link href="/signup" className="block">
            <button className="w-full bg-white/80 backdrop-blur-sm text-gray-700 py-4 rounded-2xl font-semibold text-lg border border-gray-200 shadow-lg hover:bg-white transition-all !rounded-button">
              {t.signup}
            </button>
          </Link>
        </div>

        {/* Bottom Illustration */}
        <div className="mt-12 text-center">
          <img 
            src="https://readdy.ai/api/search-image?query=Modern%20healthcare%20illustration%20showing%20medication%20bottles%2C%20pills%2C%20smartphone%20with%20health%20app%20interface%2C%20clean%20medical%20icons%2C%20soft%20blue%20and%20white%20color%20scheme%2C%20minimalist%20design%2C%20professional%20healthcare%20aesthetic%2C%20isolated%20on%20light%20blue%20gradient%20background&width=350&height=200&seq=dhakerni-hero&orientation=landscape"
            alt="Healthcare illustration"
            className="w-full max-w-sm mx-auto rounded-2xl shadow-lg object-cover object-top"
          />
        </div>
      </div>
    </div>
  );
}
