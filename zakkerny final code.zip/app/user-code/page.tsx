
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { getUserById } from '@/lib/firebaseHelpers';

export default function UserCode() {
  const [language, setLanguage] = useState('ar');
  const [userCode, setUserCode] = useState('');
  const [user, setUser] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  const translations = {
    ar: {
      title: 'رمز الربط الخاص بك',
      subtitle: 'شارك هذا الرمز مع مقدم الرعاية للربط',
      code: 'الرمز',
      copy: 'نسخ',
      copied: 'تم النسخ!',
      share: 'مشاركة',
      instructions: 'يمكن لمقدم الرعاية استخدام هذا الرمز عند إنشاء حسابه لربط حسابه بحسابك ومتابعة أدويتك',
      back: 'رجوع'
    },
    en: {
      title: 'Your Link Code',
      subtitle: 'Share this code with your caregiver to connect',
      code: 'Code',
      copy: 'Copy',
      copied: 'Copied!',
      share: 'Share',
      instructions: 'The caregiver can use this code when creating their account to link with you and monitor your medications',
      back: 'Back'
    }
  };

  const t = translations[language as keyof typeof translations];

  useEffect(() => {
    // Get current user from localStorage (in production, get from auth)
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      const userData = JSON.parse(currentUser);
      setUser(userData);
      setUserCode(userData.caregiverCode || '');
    }
  }, []);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(userCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareCode = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Zakkerny - رمز الربط',
          text: `My Zakkerny link code: ${userCode}`,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      copyToClipboard();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <button className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-arrow-left-line text-blue-600 text-lg"></i>
              </button>
            </Link>
            <h1 className="text-lg font-bold text-gray-800">{t.title}</h1>
          </div>
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium"
          >
            {language === 'ar' ? 'EN' : 'ع'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-24 px-4">
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl flex items-center justify-center shadow-xl">
            <i className="ri-qr-code-line text-white text-3xl"></i>
          </div>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {/* Code Display */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 mb-6 shadow-lg text-center">
          <p className="text-sm text-gray-600 mb-2">{t.code}</p>
          <div className="text-4xl font-bold text-blue-600 mb-4 tracking-wider font-mono">
            {userCode}
          </div>
          
          <div className="flex space-x-3">
            <button
              onClick={copyToClipboard}
              className="flex-1 bg-blue-500 text-white py-3 rounded-2xl font-semibold flex items-center justify-center !rounded-button"
            >
              <i className="ri-file-copy-line mr-2"></i>
              {copied ? t.copied : t.copy}
            </button>
            
            <button
              onClick={shareCode}
              className="flex-1 bg-green-500 text-white py-3 rounded-2xl font-semibold flex items-center justify-center !rounded-button"
            >
              <i className="ri-share-line mr-2"></i>
              {t.share}
            </button>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <i className="ri-information-line text-blue-600"></i>
            </div>
            <p className="text-gray-700 leading-relaxed">{t.instructions}</p>
          </div>
        </div>

        {/* User Info */}
        {user && (
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mt-6 shadow-lg">
            <h3 className="font-semibold text-gray-800 mb-3">معلومات الحساب</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">الاسم:</span>
                <span className="font-medium">{user.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">البريد:</span>
                <span className="font-medium">{user.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">الهاتف:</span>
                <span className="font-medium">{user.phone}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-4 gap-1">
          <Link href="/dashboard" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-home-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الرئيسية</span>
          </Link>
          <Link href="/medications" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-medicine-bottle-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">أدويتي</span>
          </Link>
          <Link href="/user-code" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-qr-code-fill text-blue-600 text-lg"></i>
            </div>
            <span className="text-xs text-blue-600 font-medium">رمز الربط</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-settings-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الإعدادات</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
