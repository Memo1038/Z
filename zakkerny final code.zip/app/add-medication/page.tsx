
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { addMedication } from '@/lib/firebaseHelpers';
import { auth } from '@/lib/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { scheduleMedicationReminder } from '@/lib/notifications';

export default function AddMedication() {
  const [language, setLanguage] = useState('ar');
  const [formData, setFormData] = useState({
    name: '',
    dosage: '',
    frequency: 1,
    times: ['08:00'],
    startDate: '',
    endDate: '',
    instructions: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [user, loading] = useAuthState(auth);
  const router = useRouter();

  const translations = {
    ar: {
      addMedication: 'إضافة دواء جديد',
      medicationName: 'اسم الدواء',
      dosage: 'الجرعة (مثل: 100mg)',
      frequency: 'عدد المرات يومياً',
      times: 'أوقات التناول',
      startDate: 'تاريخ البداية',
      endDate: 'تاريخ النهاية (اختياري)',
      instructions: 'تعليمات إضافية',
      save: 'حفظ الدواء',
      cancel: 'إلغاء',
      addTime: 'إضافة وقت',
      removeTime: 'حذف الوقت',
      success: 'تم حفظ الدواء بنجاح!'
    },
    en: {
      addMedication: 'Add New Medication',
      medicationName: 'Medication Name',
      dosage: 'Dosage (e.g., 100mg)',
      frequency: 'Times per day',
      times: 'Taking Times',
      startDate: 'Start Date',
      endDate: 'End Date (Optional)',
      instructions: 'Additional Instructions',
      save: 'Save Medication',
      cancel: 'Cancel',
      addTime: 'Add Time',
      removeTime: 'Remove Time',
      success: 'Medication saved successfully!'
    }
  };

  const t = translations[language as keyof typeof translations];

  const handleFrequencyChange = (newFreq: number) => {
    const newTimes = [];
    for (let i = 0; i < newFreq; i++) {
      if (i === 0) newTimes.push('08:00');
      else if (i === 1) newTimes.push('14:00');
      else if (i === 2) newTimes.push('20:00');
      else newTimes.push('12:00');
    }
    setFormData({ ...formData, frequency: newFreq, times: newTimes });
  };

  const handleTimeChange = (index: number, time: string) => {
    const newTimes = [...formData.times];
    newTimes[index] = time;
    setFormData({ ...formData, times: newTimes });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      alert('يرجى تسجيل الدخول أولاً');
      return;
    }

    if (!formData.name || !formData.dosage || !formData.startDate || formData.times.length === 0) {
      alert('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    setIsLoading(true);

    try {
      const medicationData = {
        userId: user.uid,
        name: formData.name,
        dosage: formData.dosage,
        frequency: parseInt(formData.frequency.toString()),
        times: formData.times,
        startDate: formData.startDate,
        endDate: formData.endDate || undefined,
        instructions: formData.instructions || undefined,
        isActive: true
      };

      const savedMedication = await addMedication(medicationData);

      for (const time of formData.times) {
        await scheduleMedicationReminder(
          formData.name,
          time,
          user.uid,
          savedMedication.id
        );
      }

      alert('تم حفظ الدواء بنجاح! ');
      router.push('/medications');

    } catch (error) {
      console.error('Error saving medication:', error);
      alert('حدث خطأ في حفظ الدواء');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">يرجى تسجيل الدخول للمتابعة</p>
          <Link href="/login" className="bg-blue-600 text-white px-6 py-3 rounded-full">
            تسجيل الدخول
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 pb-8">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/medications">
              <button className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-arrow-left-line text-blue-600 text-lg"></i>
              </button>
            </Link>
            <h1 className="text-lg font-bold text-gray-800">{t.addMedication}</h1>
          </div>
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium"
          >
            {language === 'ar' ? 'EN' : 'ع'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Medication Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.medicationName}</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>

          {/* Dosage */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.dosage}</label>
            <input
              type="text"
              value={formData.dosage}
              onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>

          {/* Frequency */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.frequency}</label>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map((freq) => (
                <button
                  key={freq}
                  type="button"
                  onClick={() => handleFrequencyChange(freq)}
                  className={`py-3 rounded-xl font-medium transition-all !rounded-button ${
                    formData.frequency === freq
                      ? 'bg-blue-500 text-white shadow-lg'
                      : 'bg-white/70 text-gray-600 shadow-lg hover:bg-white'
                  }`}
                >
                  {freq}
                </button>
              ))}
            </div>
          </div>

          {/* Times */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.times}</label>
            <div className="space-y-3">
              {formData.times.map((time, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <input
                    type="time"
                    value={time}
                    onChange={(e) => handleTimeChange(index, e.target.value)}
                    className="flex-1 bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <i className="ri-time-line text-blue-600 text-lg"></i>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.startDate}</label>
            <input
              type="date"
              value={formData.startDate}
              onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>

          {/* End Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.endDate}</label>
            <input
              type="date"
              value={formData.endDate}
              onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Instructions */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">{t.instructions}</label>
            <textarea
              value={formData.instructions}
              onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
              maxLength={500}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none h-24"
              placeholder="مثل: تناول مع الطعام، تجنب الكحول..."
            />
            <p className="text-xs text-gray-500 mt-1">{formData.instructions.length}/500</p>
          </div>

          {/* Buttons */}
          <div className="flex space-x-4 pt-4">
            <Link href="/medications" className="flex-1">
              <button
                type="button"
                className="w-full bg-gray-200 text-gray-700 py-4 rounded-2xl font-semibold text-lg shadow-lg !rounded-button"
              >
                {t.cancel}
              </button>
            </Link>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl disabled:opacity-50 !rounded-button"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  {t.save}
                </div>
              ) : (
                t.save
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
