
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { subscribeToUserMedications } from '@/lib/realTimeHelpers';
import { auth } from '@/lib/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { MedicationData } from '@/lib/firebaseHelpers';

export default function Medications() {
  const [language, setLanguage] = useState('ar');
  const [searchQuery, setSearchQuery] = useState('');
  const [medications, setMedications] = useState<any[]>([]);
  const [user, loading] = useAuthState(auth);
  const [isLoading, setIsLoading] = useState(true);

  const translations = {
    ar: {
      myMedications: 'أدويتي',
      search: 'البحث في الأدوية',
      addNew: 'إضافة دواء جديد',
      active: 'نشط',
      paused: 'متوقف',
      frequency: 'مرات يومياً',
      dosage: 'الجرعة',
      nextDose: 'الجرعة التالية',
      edit: 'تعديل',
      delete: 'حذف',
      noMedications: 'لا توجد أدوية مضافة',
      addFirstMedication: 'أضف دواءك الأول'
    },
    en: {
      myMedications: 'My Medications',
      search: 'Search medications',
      addNew: 'Add New Medication',
      active: 'Active',
      paused: 'Paused',
      frequency: 'times daily',
      dosage: 'Dosage',
      nextDose: 'Next dose',
      edit: 'Edit',
      delete: 'Delete',
      noMedications: 'No medications added',
      addFirstMedication: 'Add your first medication'
    }
  };

  const t = translations[language as keyof typeof translations];

  useEffect(() => {
    if (!user) return;

    const unsubscribe = subscribeToUserMedications(user.uid, (updatedMedications) => {
      setMedications(updatedMedications);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    const loadMedications = () => {
      try {
        const savedMedications = localStorage.getItem('medications');
        if (savedMedications) {
          const parsedMeds = JSON.parse(savedMedications);
          setMedications(parsedMeds);
          console.log('Loaded medications from storage:', parsedMeds);
        } else {
          const defaultMedications = [
            {
              id: 1,
              name: 'أسبرين',
              nameEn: 'Aspirin',
              dosage: '100mg',
              frequency: 1,
              nextDose: '08:00',
              status: 'active',
              color: 'blue'
            },
            {
              id: 2,
              name: 'فيتامين د',
              nameEn: 'Vitamin D',
              dosage: '1000 IU',
              frequency: 1,
              nextDose: '12:00',
              status: 'active',
              color: 'yellow'
            },
            {
              id: 3,
              name: 'أوميجا 3',
              nameEn: 'Omega 3',
              dosage: '500mg',
              frequency: 2,
              nextDose: '18:00',
              status: 'active',
              color: 'green'
            },
            {
              id: 4,
              name: 'كالسيوم',
              nameEn: 'Calcium',
              dosage: '600mg',
              frequency: 1,
              nextDose: '20:00',
              status: 'paused',
              color: 'orange'
            }
          ];
          setMedications(defaultMedications);
          localStorage.setItem('medications', JSON.stringify(defaultMedications));
        }
      } catch (error) {
        console.error('Error loading medications:', error);
        setMedications([]);
      }
    };

    loadMedications();
  }, []);

  const handleDeleteMedication = (medicationId: number) => {
    if (confirm('هل أنت متأكد من حذف هذا الدواء؟')) {
      const updatedMedications = medications.filter(med => med.id !== medicationId);
      setMedications(updatedMedications);
      localStorage.setItem('medications', JSON.stringify(updatedMedications));
    }
  };

  const filteredMedications = medications.filter(med =>
    (language === 'ar' ? med.name : med.nameEn)
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  );

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل الأدوية...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">يرجى تسجيل الدخول للمتابعة</p>
          <Link href="/login" className="bg-blue-600 text-white px-6 py-3 rounded-full">
            تسجيل الدخول
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <button className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-arrow-left-line text-blue-600 text-lg"></i>
              </button>
            </Link>
            <h1 className="text-lg font-bold text-gray-800">{t.myMedications}</h1>
          </div>
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium"
          >
            {language === 'ar' ? 'EN' : 'ع'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              placeholder={t.search}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl pl-12 pr-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 flex items-center justify-center">
              <i className="ri-search-line text-gray-400 text-lg"></i>
            </div>
          </div>
        </div>

        {/* Add New Button */}
        <Link href="/add-medication">
          <button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl mb-6 !rounded-button">
            <i className="ri-add-line mr-2"></i>
            {t.addNew}
          </button>
        </Link>

        {/* Medications List */}
        {filteredMedications.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-medicine-bottle-line text-3xl text-gray-400"></i>
            </div>
            <h3 className="text-lg font-semibold text-gray-600 mb-2">{t.noMedications}</h3>
            <p className="text-gray-500 mb-6">{t.addFirstMedication}</p>
            <Link href="/add-medication">
              <button className="bg-blue-500 text-white px-6 py-3 rounded-2xl font-medium !rounded-button">
                <i className="ri-add-line mr-2"></i>
                {t.addNew}
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMedications.map((med) => (
              <div key={med.id} className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-${med.color}-100`}>
                      <i className={`ri-medicine-bottle-line text-xl text-${med.color}-600`}></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800">
                        {language === 'ar' ? med.name : (med.nameEn || med.name)}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {med.dosage} • {med.frequency} {t.frequency}
                      </p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                    med.status === 'active'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {med.status === 'active' ? t.active : t.paused}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    {t.nextDose}: {med.nextDose}
                  </div>
                  <div className="flex space-x-2">
                    <Link href={`/edit-medication/${med.id}`}>
                      <button className="px-3 py-1 bg-blue-500 text-white rounded-full text-xs !rounded-button">
                        {t.edit}
                      </button>
                    </Link>
                    <button
                      onClick={() => handleDeleteMedication(med.id)}
                      className="px-3 py-1 bg-red-500 text-white rounded-full text-xs !rounded-button"
                    >
                      {t.delete}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-4 gap-1">
          <Link href="/dashboard" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-home-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الرئيسية</span>
          </Link>
          <Link href="/medications" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-medicine-bottle-fill text-blue-600 text-lg"></i>
            </div>
            <span className="text-xs text-blue-600 font-medium">{t.myMedications}</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">التقارير</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-settings-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الإعدادات</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
