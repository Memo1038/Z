'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Reports() {
  const [language, setLanguage] = useState('ar');
  const [timeRange, setTimeRange] = useState('week');

  const translations = {
    ar: {
      reports: 'التقارير',
      adherenceRate: 'معدل الالتزام',
      week: 'أسبوع',
      month: 'شهر',
      year: 'سنة',
      takenOnTime: 'تم التناول في الوقت',
      takenLate: 'تم التناول متأخراً',
      missed: 'تم التفويت',
      totalDoses: 'إجمالي الجرعات',
      recentActivity: 'النشاط الأخير',
      medicationTrends: 'اتجاهات الأدوية',
      exportReport: 'تصدير التقرير'
    },
    en: {
      reports: 'Reports',
      adherenceRate: 'Adherence Rate',
      week: 'Week',
      month: 'Month',
      year: 'Year',
      takenOnTime: 'Taken on Time',
      takenLate: 'Taken Late',
      missed: 'Missed',
      totalDoses: 'Total Doses',
      recentActivity: 'Recent Activity',
      medicationTrends: 'Medication Trends',
      exportReport: 'Export Report'
    }
  };

  const t = translations[language as keyof typeof translations];

  const adherenceData = {
    week: { onTime: 85, late: 10, missed: 5, total: 42 },
    month: { onTime: 78, late: 15, missed: 7, total: 186 },
    year: { onTime: 82, late: 12, missed: 6, total: 2190 }
  };

  const currentData = adherenceData[timeRange as keyof typeof adherenceData];

  const recentActivity = [
    { id: 1, medication: 'أسبرين', medicationEn: 'Aspirin', time: '08:00', status: 'taken', date: '2024-01-15' },
    { id: 2, medication: 'فيتامين د', medicationEn: 'Vitamin D', time: '12:30', status: 'late', date: '2024-01-15' },
    { id: 3, medication: 'أوميجا 3', medicationEn: 'Omega 3', time: '18:00', status: 'missed', date: '2024-01-14' },
    { id: 4, medication: 'كالسيوم', medicationEn: 'Calcium', time: '20:00', status: 'taken', date: '2024-01-14' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <button className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-arrow-left-line text-blue-600 text-lg"></i>
              </button>
            </Link>
            <h1 className="text-lg font-bold text-gray-800">{t.reports}</h1>
          </div>
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium"
          >
            {language === 'ar' ? 'EN' : 'ع'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Time Range Selector */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-1 mb-6 shadow-lg">
          <div className="grid grid-cols-3 gap-1">
            {['week', 'month', 'year'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                  timeRange === range
                    ? 'bg-blue-500 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-white/50'
                }`}
              >
                {t[range as keyof typeof t]}
              </button>
            ))}
          </div>
        </div>

        {/* Adherence Rate Card */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 mb-6 shadow-lg">
          <h2 className="text-lg font-bold text-gray-800 mb-4">{t.adherenceRate}</h2>
          
          {/* Circular Progress */}
          <div className="flex items-center justify-center mb-6">
            <div className="relative w-32 h-32">
              <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#E5E7EB"
                  strokeWidth="8"
                  fill="none"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#3B82F6"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${currentData.onTime * 2.51} 251.2`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-gray-800">{currentData.onTime}%</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-4 h-4 bg-green-500 rounded-full mx-auto mb-2"></div>
              <p className="text-2xl font-bold text-gray-800">{currentData.onTime}%</p>
              <p className="text-xs text-gray-600">{t.takenOnTime}</p>
            </div>
            <div className="text-center">
              <div className="w-4 h-4 bg-yellow-500 rounded-full mx-auto mb-2"></div>
              <p className="text-2xl font-bold text-gray-800">{currentData.late}%</p>
              <p className="text-xs text-gray-600">{t.takenLate}</p>
            </div>
            <div className="text-center">
              <div className="w-4 h-4 bg-red-500 rounded-full mx-auto mb-2"></div>
              <p className="text-2xl font-bold text-gray-800">{currentData.missed}%</p>
              <p className="text-xs text-gray-600">{t.missed}</p>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="text-center">
              <p className="text-sm text-gray-600">{t.totalDoses}</p>
              <p className="text-xl font-bold text-gray-800">{currentData.total}</p>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 mb-6 shadow-lg">
          <h2 className="text-lg font-bold text-gray-800 mb-4">{t.recentActivity}</h2>
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    activity.status === 'taken' 
                      ? 'bg-green-100' 
                      : activity.status === 'late' 
                        ? 'bg-yellow-100' 
                        : 'bg-red-100'
                  }`}>
                    <i className={`text-sm ${
                      activity.status === 'taken' 
                        ? 'ri-check-line text-green-600' 
                        : activity.status === 'late' 
                          ? 'ri-time-line text-yellow-600' 
                          : 'ri-close-line text-red-600'
                    }`}></i>
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">
                      {language === 'ar' ? activity.medication : activity.medicationEn}
                    </p>
                    <p className="text-xs text-gray-600">{activity.time}</p>
                  </div>
                </div>
                <span className="text-xs text-gray-500">{activity.date}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Chart Placeholder */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 mb-6 shadow-lg">
          <h2 className="text-lg font-bold text-gray-800 mb-4">{t.medicationTrends}</h2>
          <div className="h-48 flex items-center justify-center">
            <img 
              src="https://readdy.ai/api/search-image?query=Clean%20minimal%20medication%20adherence%20chart%20showing%20weekly%20trends%2C%20blue%20and%20green%20gradient%20colors%2C%20professional%20healthcare%20analytics%20visualization%2C%20modern%20dashboard%20style%20chart%20with%20clear%20data%20points%20and%20smooth%20curves%2C%20isolated%20on%20white%20background&width=300&height=180&seq=medication-chart&orientation=landscape"
              alt="Medication trends chart"
              className="w-full h-full object-cover object-top rounded-xl"
            />
          </div>
        </div>

        {/* Export Button */}
        <button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl mb-6 !rounded-button">
          <i className="ri-download-line mr-2"></i>
          {t.exportReport}
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-4 gap-1">
          <Link href="/dashboard" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-home-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الرئيسية</span>
          </Link>
          <Link href="/medications" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-medicine-bottle-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">أدويتي</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-fill text-blue-600 text-lg"></i>
            </div>
            <span className="text-xs text-blue-600 font-medium">{t.reports}</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-settings-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الإعدادات</span>
          </Link>
        </div>
      </div>
    </div>
  );
}