'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function Login() {
  const [language, setLanguage] = useState('ar');
  const [accountType, setAccountType] = useState('user');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const translations = {
    ar: {
      title: 'تسجيل الدخول',
      user: 'مستخدم',
      caregiver: 'مقدم رعاية',
      email: 'البريد الإلكتروني',
      password: 'كلمة المرور',
      login: 'دخول',
      forgotPassword: 'نسيت كلمة المرور؟',
      noAccount: 'ليس لديك حساب؟',
      signup: 'إنشاء حساب',
      back: 'رجوع'
    },
    en: {
      title: 'Login',
      user: 'User',
      caregiver: 'Caregiver',
      email: 'Email',
      password: 'Password',
      login: 'Login',
      forgotPassword: 'Forgot Password?',
      noAccount: "Don't have an account?",
      signup: 'Sign Up',
      back: 'Back'
    }
  };

  const t = translations[language as keyof typeof translations];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      if (accountType === 'user') {
        router.push('/dashboard');
      } else {
        router.push('/caregiver-dashboard');
      }
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <Link href="/">
          <button className="w-10 h-10 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg">
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </button>
        </Link>
        <button
          onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          className="bg-white/80 backdrop-blur-sm px-3 py-2 rounded-full shadow-lg text-sm font-medium text-gray-700"
        >
          {language === 'ar' ? 'EN' : 'العربية'}
        </button>
      </div>

      <div className="px-6 pt-8">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 rounded-3xl flex items-center justify-center shadow-xl overflow-hidden bg-white">
            <img 
              src="https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png"
              alt="ذكرني"
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">{t.title}</h1>
        </div>

        {/* Account Type Toggle */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-1 mb-6 shadow-lg">
          <div className="grid grid-cols-2 gap-1">
            <button
              onClick={() => setAccountType('user')}
              className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                accountType === 'user'
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'text-gray-600 hover:bg-white/50'
              }`}
            >
              {t.user}
            </button>
            <button
              onClick={() => setAccountType('caregiver')}
              className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                accountType === 'caregiver'
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'text-gray-600 hover:bg-white/50'
              }`}
            >
              {t.caregiver}
            </button>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <input
              type="email"
              placeholder={t.email}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>
          <div>
            <input
              type="password"
              placeholder={t.password}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-white/70 backdrop-blur-sm border-none rounded-2xl px-4 py-4 text-gray-700 placeholder-gray-500 shadow-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              required
            />
          </div>
          
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl hover:shadow-2xl transition-all disabled:opacity-50 !rounded-button"
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                {t.login}
              </div>
            ) : (
              t.login
            )}
          </button>
        </form>

        {/* Footer Links */}
        <div className="text-center mt-6 space-y-3">
          <button className="text-blue-600 text-sm font-medium">
            {t.forgotPassword}
          </button>
          <div className="text-gray-600 text-sm">
            {t.noAccount}{' '}
            <Link href="/signup" className="text-blue-600 font-medium">
              {t.signup}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}