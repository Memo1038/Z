'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Settings() {
  const [language, setLanguage] = useState('ar');
  const [notifications, setNotifications] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [vibrationEnabled, setVibrationEnabled] = useState(true);
  const [accountType, setAccountType] = useState('user');

  const translations = {
    ar: {
      settings: 'الإعدادات',
      account: 'الحساب',
      switchToCaregiver: 'التبديل إلى مقدم رعاية',
      switchToUser: 'التبديل إلى مستخدم',
      notifications: 'الإشعارات',
      enableNotifications: 'تفعيل الإشعارات',
      soundAlerts: 'التنبيهات الصوتية',
      vibration: 'الاهتزاز',
      privacy: 'الخصوصية',
      dataSharing: 'مشاركة البيانات',
      backup: 'النسخ الاحتياطي',
      language: 'اللغة',
      arabic: 'العربية',
      english: 'الإنجليزية',
      support: 'الدعم',
      helpCenter: 'مركز المساعدة',
      contactUs: 'تواصل معنا',
      about: 'حول التطبيق',
      version: 'الإصدار',
      logout: 'تسجيل الخروج'
    },
    en: {
      settings: 'Settings',
      account: 'Account',
      switchToCaregiver: 'Switch to Caregiver',
      switchToUser: 'Switch to User',
      notifications: 'Notifications',
      enableNotifications: 'Enable Notifications',
      soundAlerts: 'Sound Alerts',
      vibration: 'Vibration',
      privacy: 'Privacy',
      dataSharing: 'Data Sharing',
      backup: 'Backup',
      language: 'Language',
      arabic: 'Arabic',
      english: 'English',
      support: 'Support',
      helpCenter: 'Help Center',
      contactUs: 'Contact Us',
      about: 'About App',
      version: 'Version',
      logout: 'Logout'
    }
  };

  const t = translations[language as keyof typeof translations];

  const handleAccountTypeSwitch = () => {
    const newType = accountType === 'user' ? 'caregiver' : 'user';
    setAccountType(newType);
    
    // Navigate to appropriate dashboard
    if (newType === 'caregiver') {
      window.location.href = '/caregiver-dashboard';
    } else {
      window.location.href = '/dashboard';
    }
  };

  const ToggleSwitch = ({ enabled, onToggle }: { enabled: boolean; onToggle: () => void }) => (
    <button
      onClick={onToggle}
      className={`relative w-12 h-7 rounded-full transition-colors ${
        enabled ? 'bg-blue-500' : 'bg-gray-300'
      }`}
    >
      <div
        className={`absolute w-5 h-5 bg-white rounded-full top-1 transition-transform ${
          enabled ? 'translate-x-6' : 'translate-x-1'
        }`}
      />
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <button className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-arrow-left-line text-blue-600 text-lg"></i>
              </button>
            </Link>
            <h1 className="text-lg font-bold text-gray-800">{t.settings}</h1>
          </div>
          <button
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium"
          >
            {language === 'ar' ? 'EN' : 'ع'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="pt-20 px-4">
        {/* Account Section */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.account}</h2>
          
          <button
            onClick={handleAccountTypeSwitch}
            className="w-full flex items-center justify-between py-3 px-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <i className={`ri-${accountType === 'user' ? 'heart' : 'user'}-line text-white`}></i>
              </div>
              <span className="font-medium text-gray-800">
                {accountType === 'user' ? t.switchToCaregiver : t.switchToUser}
              </span>
            </div>
            <i className="ri-arrow-right-line text-gray-400"></i>
          </button>
        </div>

        {/* Notifications Section */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.notifications}</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-notification-line text-blue-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.enableNotifications}</span>
              </div>
              <ToggleSwitch enabled={notifications} onToggle={() => setNotifications(!notifications)} />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-volume-up-line text-blue-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.soundAlerts}</span>
              </div>
              <ToggleSwitch enabled={soundEnabled} onToggle={() => setSoundEnabled(!soundEnabled)} />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-smartphone-line text-blue-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.vibration}</span>
              </div>
              <ToggleSwitch enabled={vibrationEnabled} onToggle={() => setVibrationEnabled(!vibrationEnabled)} />
            </div>
          </div>
        </div>

        {/* Privacy Section */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.privacy}</h2>
          
          <div className="space-y-3">
            <Link href="/data-sharing" className="flex items-center justify-between py-2">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <i className="ri-shield-check-line text-green-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.dataSharing}</span>
              </div>
              <i className="ri-arrow-right-line text-gray-400"></i>
            </Link>
            
            <Link href="/backup" className="flex items-center justify-between py-2">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <i className="ri-cloud-line text-purple-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.backup}</span>
              </div>
              <i className="ri-arrow-right-line text-gray-400"></i>
            </Link>
          </div>
        </div>

        {/* Language Section */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.language}</h2>
          
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setLanguage('ar')}
              className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                language === 'ar'
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {t.arabic}
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`py-3 px-4 rounded-xl font-medium transition-all !rounded-button ${
                language === 'en'
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {t.english}
            </button>
          </div>
        </div>

        {/* Support Section */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.support}</h2>
          
          <div className="space-y-3">
            <Link href="/help" className="flex items-center justify-between py-2">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <i className="ri-question-line text-orange-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.helpCenter}</span>
              </div>
              <i className="ri-arrow-right-line text-gray-400"></i>
            </Link>
            
            <Link href="/contact" className="flex items-center justify-between py-2">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-mail-line text-blue-600"></i>
                </div>
                <span className="font-medium text-gray-800">{t.contactUs}</span>
              </div>
              <i className="ri-arrow-right-line text-gray-400"></i>
            </Link>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-4 shadow-lg">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.about}</h2>
          
          <div className="text-center py-4">
            <div className="w-16 h-16 mx-auto mb-3 rounded-3xl flex items-center justify-center shadow-xl overflow-hidden bg-white">
              <img 
                src="https://static.readdy.ai/image/8e4e1080b446e3c1381d01612413cefd/b246a9a67ce860d0d900a7035297b2a1.png"
                alt="ذكرني"
                className="w-full h-full object-contain"
              />
            </div>
            <h3 className="font-bold text-gray-800 text-lg font-[\'Pacifico\']">
              {language === 'ar' ? 'ذكرني' : 'Dhakerni'}
            </h3>
            <p className="text-sm text-gray-600 mt-1">{t.version} 1.0.0</p>
          </div>
        </div>

        {/* Logout Button */}
        <Link href="/">
          <button className="w-full bg-red-500 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl mb-6 !rounded-button">
            <i className="ri-logout-circle-line mr-2"></i>
            {t.logout}
          </button>
        </Link>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-4 gap-1">
          <Link href="/dashboard" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-home-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">الرئيسية</span>
          </Link>
          <Link href="/medications" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-medicine-bottle-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">أدويتي</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">التقارير</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-settings-fill text-blue-600 text-lg"></i>
            </div>
            <span className="text-xs text-blue-600 font-medium">{t.settings}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}