
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { subscribeToCaregiverNotifications, subscribeToLinkedUsers, markNotificationAsRead } from '@/lib/realTimeHelpers';
import { auth } from '@/lib/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { NotificationData, UserData } from '@/lib/firebaseHelpers';

export default function CaregiverDashboard() {
  const [user, loading] = useAuthState(auth);
  const [language, setLanguage] = useState('ar');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [notifications, setNotifications] = useState<NotificationData[]>([]);
  const [linkedUsers, setLinkedUsers] = useState<UserData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const translations = {
    ar: {
      caregiverDashboard: 'لوحة مقدم الرعاية',
      connectedUsers: 'المستخدمون المتصلون',
      notifications: 'التنبيهات',
      payments: 'المدفوعات',
      settings: 'الإعدادات',
      noNotifications: 'لا توجد تنبيهات جديدة',
      viewAll: 'عرض الكل',
      manage: 'إدارة',
      payFees: 'دفع الرسوم'
    },
    en: {
      caregiverDashboard: 'Caregiver Dashboard',
      connectedUsers: 'Connected Users',
      notifications: 'Notifications',
      payments: 'Payments',
      settings: 'Settings',
      noNotifications: 'No new notifications',
      viewAll: 'View All',
      manage: 'Manage',
      payFees: 'Pay Fees'
    }
  };

  const t = translations[language as keyof typeof translations];

  const connectedUsers = [
    { id: 1, name: 'أحمد محمد', nameEn: 'Ahmed Mohamed', status: 'active', medsCount: 5 },
    { id: 2, name: 'فاطمة علي', nameEn: 'Fatima Ali', status: 'warning', medsCount: 3 },
    { id: 3, name: 'محمد حسن', nameEn: 'Mohamed Hassan', status: 'active', medsCount: 7 }
  ];

  useEffect(() => {
    if (!user) return;

    const unsubscribeNotifications = subscribeToCaregiverNotifications(
      user.uid, 
      (updatedNotifications) => {
        setNotifications(updatedNotifications);
        setIsLoading(false);
      }
    );

    const unsubscribeUsers = subscribeToLinkedUsers(
      user.uid,
      (updatedUsers) => {
        setLinkedUsers(updatedUsers);
      }
    );

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);

    return () => {
      unsubscribeNotifications();
      unsubscribeUsers();
      clearInterval(timer);
    };
  }, [user]);

  const handleMarkAsRead = async (notificationId: string) => {
    await markNotificationAsRead(notificationId);
  };

  const renderNotifications = () => (
    <div className="bg-white rounded-2xl p-6 mb-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">التنبيهات الفورية</h3>
        <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-sm">
          {notifications.length} جديد
        </span>
      </div>

      {notifications.length === 0 ? (
        <p className="text-gray-500 text-center py-4">لا توجد تنبيهات جديدة</p>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div 
              key={notification.id}
              className="border-r-4 border-red-500 bg-red-50 p-4 rounded-lg cursor-pointer hover:bg-red-100 transition-colors"
              onClick={() => handleMarkAsRead(notification.id)}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-semibold text-red-800">{notification.title}</h4>
                  <p className="text-red-600 text-sm mt-1">{notification.message}</p>
                  <p className="text-red-500 text-xs mt-2">
                    {notification.createdAt?.toDate?.()?.toLocaleString('ar-SA') || 'الآن'}
                  </p>
                </div>
                <div className="w-3 h-3 bg-red-500 rounded-full flex-shrink-0 mt-1"></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 pb-20">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm z-40 px-4 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-gray-800">{t.caregiverDashboard}</h1>
            <p className="text-sm text-gray-600" suppressHydrationWarning={true}>
              {currentTime.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
              className="bg-purple-100 text-purple-600 px-3 py-1 rounded-full text-sm font-medium"
            >
              {language === 'ar' ? 'EN' : 'ع'}
            </button>
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
              <i className="ri-heart-line text-white text-lg"></i>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pt-24 px-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 bg-purple-100 rounded-full flex items-center justify-center">
              <i className="ri-group-line text-purple-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">3</p>
            <p className="text-xs text-gray-600">{t.connectedUsers}</p>
          </div>
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 bg-orange-100 rounded-full flex items-center justify-center">
              <i className="ri-notification-line text-orange-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">{notifications.length}</p>
            <p className="text-xs text-gray-600">{t.notifications}</p>
          </div>
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-money-dollar-circle-line text-green-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">$150</p>
            <p className="text-xs text-gray-600">{t.payments}</p>
          </div>
        </div>

        {/* Connected Users */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800">{t.connectedUsers}</h2>
            <button className="text-purple-600 text-sm font-medium">{t.viewAll}</button>
          </div>
          <div className="space-y-3">
            {connectedUsers.map((user) => (
              <div key={user.id} className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
                      <i className="ri-user-line text-white text-lg"></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800">
                        {language === 'ar' ? user.name : user.nameEn}
                      </h3>
                      <p className="text-sm text-gray-600">{user.medsCount} أدوية</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${user.status === 'active' ? 'bg-green-500' : 'bg-orange-500'}`}></div>
                    <Link href={`/manage-user/${user.id}`}>
                      <button className="px-3 py-1 bg-purple-500 text-white rounded-full text-xs !rounded-button">
                        {t.manage}
                      </button>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Notifications */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800">{t.notifications}</h2>
            <button className="text-purple-600 text-sm font-medium">{t.viewAll}</button>
          </div>
          {notifications.length > 0 ? (
            <div className="space-y-3">
              {notifications.map((notification) => (
                <div key={notification.id} className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${notification.type === 'missed' ? 'bg-red-100' : 'bg-orange-100'}`}>
                      <i className={`${notification.type === 'missed' ? 'ri-close-line text-red-600' : 'ri-time-line text-orange-600'}`}></i>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-800">
                        {language === 'ar' ? notification.user : notification.userEn}
                      </p>
                      <p className="text-sm text-gray-600">
                        {language === 'ar' ? notification.message : notification.messageEn}
                      </p>
                    </div>
                    <span className="text-xs text-gray-500">{notification.time}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 text-center shadow-lg">
              <div className="w-12 h-12 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
                <i className="ri-notification-off-line text-gray-400 text-xl"></i>
              </div>
              <p className="text-gray-600">{t.noNotifications}</p>
            </div>
          )}
        </div>

        {renderNotifications()}

        {/* Pay Fees Button */}
        <Link href="/payments">
          <button className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-4 rounded-2xl font-semibold text-lg shadow-xl mb-6 !rounded-button">
            <i className="ri-money-dollar-circle-line mr-2"></i>
            {t.payFees}
          </button>
        </Link>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2">
        <div className="grid grid-cols-4 gap-1">
          <Link href="/caregiver-dashboard" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-home-fill text-purple-600 text-lg"></i>
            </div>
            <span className="text-xs text-purple-600 font-medium">الرئيسية</span>
          </Link>
          <Link href="/users" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-group-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">المستخدمون</span>
          </Link>
          <Link href="/payments" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-money-dollar-circle-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">{t.payments}</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center py-2 px-1">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-settings-line text-gray-500 text-lg"></i>
            </div>
            <span className="text-xs text-gray-500">{t.settings}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
